import { GenerateCodeError } from '../../utils/getCodeError.js';
import { HandleError } from '../../utils/HandleError.js';
import { pool } from '../../db/db.js';
import sql from 'mssql';
import { typeError } from '../../dictionary/typeError.js';
import { modules } from '../../dictionary/modules.js';


// Verifica si el DV del cliente ya está registrado en el sistema
export const ValidateDV_Client = async (idClient, DV) => {
    try {
        // Valida si el DV es undefined
        if (!DV) {
            return null
        }

        const request = await pool.request();
        request.input("DV", sql.Int, DV);

        let query = `
            SELECT 1 FROM CLIENTES
            WHERE DV = @DV
        `;

        // Valida que idCliente no sea undefined
        if (idClient) {
            request.input("IDCliente", sql.VarChar, idClient);
            query += ` AND id_cliente <> @IDCliente`
        }

        const result = await request.query(query)

        // Valida si la consulta tiene datos
        if (result.recordset.length > 0) {
            return true
        }

        return false
    } catch (error) {
        const code = GenerateCodeError(modules.CLIENTS, typeError.CLIENTS.POST);
        HandleError(code, error.message, 'querys/Clients/validateDV/ValidateDV_Client', error);
        throw new Error('Ha ocurrido un error al crear al cliente');
    }
}