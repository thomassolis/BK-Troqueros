import { HandleError } from '../../utils/HandleError.js';
import { GetTruckVanId } from '../../querys/TruckVan/getTruckVanId.js';
import { DateConverterSQL } from '../../auxiliary functions/dateConverter.js';
import { GetLinksPreviewFiles } from '../../fileManager/getFiles.js';
import { modules } from '../../dictionary/modules.js';
import { typeError } from '../../dictionary/typeError.js';
import { GenerateCodeError } from '../../utils/getCodeError.js';

//Obtiene el furgon por ID
export const CtrGetTruckVanId = async (req, res) => {
    try {
        const protocol = req.protocol; //protocolo => http ó https
        const host = req.get('host'); //localhost:puerto
        const linkDownload = `${protocol}://${host}/api/preview`;

        //obtiene el id del furgon
        const idTruckVan = req.params.id;

        //valida que el id del furgon no sea nulo
        if (!idTruckVan) {
            return res.status(404).json({success: false, message: 'No se pudo obtener los datos del cabezal'});
        }

        //obtiene la info del furgon
        const data = await GetTruckVanId(idTruckVan);

        //verifica que chasis no este nulo
        if (!data) {
            return res.status(404).json({success: false, message: 'No se pudo obtener los datos'});
        }        

        //obtiene la data con las fechas formateas (DD/MM/YYYY)
        //obtiene los links de descarga de los archivos existentes
        const truckVan = {
            ...data,  // Mantiene todos los demás datos de la fila sin cambios
            fecha_expedicion_poliza: DateConverterSQL(data.fecha_expedicion_poliza),
            fecha_caducidad_poliza: DateConverterSQL(data.fecha_caducidad_poliza),
            fecha_renovacion_revisado: DateConverterSQL(data.fecha_renovacion_revisado),
            fecha_ultimo_revisado: DateConverterSQL(data.fecha_ultimo_revisado),
            foto_poliza: GetLinksPreviewFiles(linkDownload, data.foto_poliza),
            foto_revisado: GetLinksPreviewFiles(linkDownload, data.foto_revisado),
        };

        return res.status(200).json({success: true, message: 'Data enviada', data: truckVan});
    } catch (error) {
        const code = GenerateCodeError(modules.FURGONES, typeError.FURGONES.GET);
        HandleError(code, error.message, 'controllers/TruckVan/getTruckVanIdController/CtrGetTruckVanId', error);
        return res.status(500).json({success: false, message: `${error.message}. Inténtelo más tarde` });
    }
}