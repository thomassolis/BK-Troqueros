import { HandleError } from '../../utils/HandleError.js';
import { GetChassisId } from '../../querys/Chassis/getChassisId.js';
import { DateConverterSQL } from '../../auxiliary functions/dateConverter.js';
import { GetLinksPreviewFiles } from '../../fileManager/getFiles.js';
import { GenerateCodeError } from '../../utils/getCodeError.js';
import { modules } from '../../dictionary/modules.js';
import { typeError } from '../../dictionary/typeError.js';

//Obtiene todos los chasis que hay en el sistema
export const CtrGetChassisId = async (req, res) => {
    try {
        const protocol = req.protocol; //protocolo => http ó https
        const host = req.get('host'); //localhost:puerto
        const linkDownload = `${protocol}://${host}/api/preview`;

        //obtiene el id del chasis
        const idChassis = req.params.id;

        //valida que el id del chasis no sea nulo
        if (!idChassis) {
            return res.status(404).json({success: false, message: 'No se pudo obtener los datos del chasis'});
        }

        //obtiene la info del chasis y reduce el anidamiento del array
        const data = await GetChassisId(idChassis);

        //verifica que chasis no este nulo
        if (!data) {
            return res.status(404).json({success: false, message: 'No se pudo obtener los datos'});
        }

        const chassis = {
            ...data,  // Mantiene todos los demás datos de la fila sin cambios
            fecha_expedicion_poliza: DateConverterSQL(data.fecha_expedicion_poliza),
            fecha_caducidad_poliza: DateConverterSQL(data.fecha_caducidad_poliza),
            fecha_renovacion_revisado: DateConverterSQL(data.fecha_renovacion_revisado),
            fecha_ultimo_revisado: DateConverterSQL(data.fecha_ultimo_revisado),
            foto_poliza: GetLinksPreviewFiles(linkDownload, data.foto_poliza),
            foto_revisado: GetLinksPreviewFiles(linkDownload, data.foto_revisado),
        };        

        return res.status(200).json({success: true, message: 'Data enviada', data: chassis});
    } catch (error) {
        const code = GenerateCodeError(modules.CHASISES, typeError.CHASISES.GET);
        HandleError(code, error.message, 'controllers/chassis/getChassisController/CtrGetChassis', error);
        return res.status(500).json({success: false, message: `${error.message}. Inténtelo más tarde` });
    }
}