
import { InitSocket } from './socket/socket.js';
import app from './App.js';
import { createServer } from 'http';
import dotenv from 'dotenv';

dotenv.config();

const PORT = process.env.PORT || 3880;

const server = createServer(app);

const io = InitSocket(server);
app.set('io', io);

server.listen(PORT, () => {
  console.log(`Servidor corriendo en https://netserpro.com:${PORT}`);
});
